drop database if exists ahorcado;
CREATE DATABASE ahorcado;

USE ahorcado;

CREATE TABLE Jugador (
    Nombre VARCHAR(50) PRIMARY KEY,
    PartidasJugadas INT DEFAULT 0,
    PartidasGanadas INT DEFAULT 0,
    
    IntentosTotales INT DEFAULT 0,
    AciertosTotales INT DEFAULT 0
);

CREATE TABLE PartidaJugador (
    ID INT AUTO_INCREMENT PRIMARY KEY,  -- Clave primaria única para identificar partidas
    NombreJugador VARCHAR(50),
    
    Intentos INT NOT NULL,
    Aciertos int not null,
    TematicaEscogida VARCHAR(100),
    FOREIGN KEY (NombreJugador) REFERENCES Jugador(Nombre) ON DELETE CASCADE
);

insert into jugador (nombre, PartidasJugadas, PartidasGanadas, IntentosTotales, AciertosTotales) values ("invitado", 0,0,0,0);

select * from jugador;
select * from partidajugador;