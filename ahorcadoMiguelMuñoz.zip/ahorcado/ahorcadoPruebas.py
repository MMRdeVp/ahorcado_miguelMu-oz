from tkinter import messagebox
import mysql.connector
import tkinter as tk
import random


# Conexión a la base de datos
conexion = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="ahorcado"
)
cursor = conexion.cursor()



# Listas de palabras
frutas = ['manzana', 'platano', 'naranja', 'fresa', 'uva', 'pera', 'mango', 'pina', 'sandia', 'melon', 'cereza', 'kiwi', 'limon', 'durazno', 'ciruela', 'papaya', 'mandarina', 'granada', 'frambuesa', 'mora', 'arandano', 'higo', 'coco', 'maracuya', 'guayaba']
infor = ['algoritmo', 'base', 'python', 'java', 'c', 'red', 'servidor', 'cliente', 'firewall', 'api', 'cloud', 'virtualizacion', 'git', 'javascript', 'html', 'css', 'linux', 'windows', 'algoritmos', 'compilador', 'debugger', 'stack', 'queue', 'framework', 'database', 'blockchain', 'ciberseguridad']
nombres = ['ana', 'carlos', 'maria', 'jose', 'luis', 'marta', 'pedro', 'laura', 'javier', 'sara', 'david', 'raul', 'andrea', 'pablo', 'carla', 'diego', 'eva', 'francisco', 'sofia', 'miguel', 'cristina', 'juan', 'irene', 'angel', 'fernando', 'rosa']

# Variables globales
palabra = ""
barrasbajas = ""
intentos = 0
aciertos = 0
fallos = 1
ganada = False

def empezar(nombre, tema):
    global palabra, barrasbajas

    if tema == "null":
        tk.messagebox.showinfo("INFO", "Debes elegir una temática")
        return

    if not nombre:
        nombre = "invitado"

    # Consulta en la base de datos
    cursor.execute(f"SELECT * FROM Jugador WHERE Nombre = '{nombre.lower()}'")
    jugador = cursor.fetchall()

    if len(jugador) == 0:
        tk.messagebox.showinfo("INFO", "No existe ningún jugador con ese nombre.\nSe creará uno nuevo.")
        cursor.execute("INSERT INTO Jugador (Nombre) VALUES (%s)", (nombre.lower(),))
        conexion.commit()
    else:
        tk.messagebox.showinfo("INFO", f"Accediendo al perfil de {nombre}")

    # Seleccionar palabra y tema
    if tema == "fruta":
        palabra = random.choice(frutas)
        tema_texto = "Frutas"
    elif tema == "info":
        palabra = random.choice(infor)
        tema_texto = "Infor\nmática"
    elif tema == "nombres":
        palabra = random.choice(nombres)
        tema_texto = "Nombres"

    barrasbajas = "_" * len(palabra)  # Inicializar barras bajas
    root.destroy()  # Cerrar la ventana principal
    juego(nombre, tema_texto)  # Iniciar el juego


def juego(nombre, tema):
    global intentos, aciertos, barrasbajas, fallos, ganada

    # Ventana del juego
    juego = tk.Tk()
    juego.title("Ahorcado")
    juego.geometry("1000x600")
    juego.resizable(False, False)
    juego.configure(bg="black")

    # Imagen del ahorcado (opcional)
    img = tk.PhotoImage(file=f"imgs/{fallos}.png")
    imgLabel = tk.Label(juego, image=img, bg="black")
    imgLabel.grid(row=0, column=0)

    # Panel de juego
    panel = tk.Frame(juego, bg="black")
    panel.grid(row=0, column=1)

    tk.Label(panel, text=f"{tema}", font=("Georgia", 70, "bold"), pady=20, bg="black", fg="white").grid(row=0, column=0, columnspan=2, sticky="w")

    guessed = tk.Label(panel, text=meterespacios(barrasbajas), font=("Verdana", 20, "bold"), pady=20, bg="black", fg="white")
    guessed.grid(row=1, column=0, pady=20, sticky="w")

    guesses = tk.Entry(panel, font=("Verdana", 20), width=15)
    guesses.grid(pady=20, row=2, column=0, sticky="w")


    guesses.bind("<Return>", lambda event: probar())


    usadas = tk.Label(panel, text="Letras usadas:", font=("Verdana", 20, "bold"), pady=20, bg="black", fg="white")
    usadas.grid(row=3, column=0, sticky="w")



    # Funciones

    def probar():
        global barrasbajas, intentos, aciertos, fallos, img, ganada
        print(fallos)

        letra = guesses.get().lower()
        if not letra or len(letra) != 1:
            tk.messagebox.showinfo("INFO", "Introduce una letra válida")
            return

        if letra in palabra:
            nuevas_barras = list(barrasbajas)
            for i, char in enumerate(palabra):
                if char == letra:
                    nuevas_barras[i] = letra
                    aciertos += 1
            barrasbajas = "".join(nuevas_barras)
            guessed.config(text=meterespacios(barrasbajas))
            usadas.config(text=f"Letras usadas: {', '.join(list(set(guesses.get().lower())))}")
        else:
            intentos += 1
            fallos += 1

            if fallos == 8:
                tk.messagebox.showinfo("INFO", f"¡Has perdido!\nLa palabra era: {palabra}")


                guardar_partida(nombre, intentos, aciertos, tema, ganada)

                juego.destroy()

            if fallos > 8:
                pass
            else:
                img = tk.PhotoImage(file=f"imgs/{fallos}.png")
                imgLabel.config(image=img, bg="black")


        if "_" not in barrasbajas:
            tk.messagebox.showinfo("INFO", "¡Has ganado!")
            guardar_partida(nombre, intentos, aciertos, tema, ganada)
            ganada = True
            juego.destroy()

    tk.Button(panel, text="Probar", command=probar, font=("Verdana", 13, "bold"), bg="yellow", fg="black").grid(pady=20, row=2, column=1, padx=10, sticky="w")

    juego.mainloop()


def meterespacios(palabra):
    return " ".join(palabra)




def guardar_partida(nombre, intentos, aciertos, tema, ganada):
    try:
        cursor.execute("INSERT INTO PartidaJugador (NombreJugador, Intentos, Aciertos, TematicaEscogida) VALUES (%s, %s, %s, %s)", (nombre.lower(), intentos, aciertos, tema))
        if ganada:
            cursor.execute("UPDATE Jugador SET PartidasGanadas = PartidasGanadas + 1 WHERE Nombre = %s", (nombre.lower(),))
        cursor.execute("UPDATE Jugador SET PartidasJugadas = PartidasJugadas + 1 WHERE Nombre = %s", (nombre.lower(),))
        cursor.execute("SELECT intentostotales from Jugador WHERE Nombre = %s", (nombre.lower(),))
        intentostotales = cursor.fetchone()[0]
        cursor.execute("UPDATE Jugador SET intentostotales = %s WHERE Nombre = %s", (intentostotales + intentos, nombre.lower()))
        cursor.execute("SELECT aciertostotales from Jugador WHERE Nombre = %s", (nombre.lower(),))
        aciertostotales = cursor.fetchone()[0]
        cursor.execute("UPDATE Jugador SET aciertostotales = %s WHERE Nombre = %s", (aciertostotales + aciertos, nombre.lower()))

        conexion.commit()
    except Exception as e:
        tk.messagebox.showerror("ERROR", f"No se pudo guardar la partida: {e}")


# Ventana inicial
root = tk.Tk()
root.title("Ahorcado")
root.geometry("600x500")
root.resizable(False, False)
root.configure(bg="black")

tk.Label(root, text="Ahorcado", font=("Georgia", 70, "bold"), pady=20, bg="black", fg="white").pack()
tk.Label(root, text="Introduce tu nombre", font=("Verdana", 20, "bold"), bg="black", fg="white").pack()

textbox = tk.Entry(root, font=("Verdana", 20), width=15)
textbox.pack(pady=20)

tematicas = tk.StringVar(root, value="null")
botones = tk.Frame(root, bg="black")
botones.pack(anchor="center", pady=30)

tk.Radiobutton(botones, text="Fruta", value="fruta", variable=tematicas, font=("Verdana", 15, "bold"), bg="black", fg="white", selectcolor="black").pack(side="left", padx=5)
tk.Radiobutton(botones, text="Informática", value="info", variable=tematicas, font=("Verdana", 15, "bold"), bg="black", fg="white", selectcolor="black").pack(side="left", padx=5)
tk.Radiobutton(botones, text="Nombres", value="nombres", variable=tematicas, font=("Verdana", 15, "bold"), bg="black", fg="white", selectcolor="black").pack(side="left", padx=5)

tk.Button(root, text="Jugar", command=lambda: empezar(textbox.get(), tematicas.get()), font=("Verdana", 20, "bold"), bg="yellow", fg="black").pack(pady=20)

root.mainloop()
